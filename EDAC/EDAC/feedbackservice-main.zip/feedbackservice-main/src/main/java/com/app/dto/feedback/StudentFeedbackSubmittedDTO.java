package com.app.dto.feedback;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class StudentFeedbackSubmittedDTO {
	boolean isSubmitted;
}
		
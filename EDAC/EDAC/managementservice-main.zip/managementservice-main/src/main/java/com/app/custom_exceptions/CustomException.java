package com.app.custom_exceptions;

public class CustomException extends RuntimeException {
    // constructors
	public CustomException() {
		
	}
}
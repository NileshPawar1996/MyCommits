package com.app.dtos.teacher;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class GetCourseBatchModuleByTeacherId {
	private List<?> id;
//	private List<Long> batchId;
//	private List<Long> moduleId;
}

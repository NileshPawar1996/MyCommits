//created by Aditya Shinde
package com.app.pojos;

public enum Role {
	ADMIN, TEACHER
}

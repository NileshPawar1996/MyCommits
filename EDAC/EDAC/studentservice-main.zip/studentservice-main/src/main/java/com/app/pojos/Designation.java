//created by : Rajvardhan Shinde
package com.app.pojos;

public enum Designation {
	TESTER, DEVOPS_ENGINEER, SOFTWARE_ENGINEER
}

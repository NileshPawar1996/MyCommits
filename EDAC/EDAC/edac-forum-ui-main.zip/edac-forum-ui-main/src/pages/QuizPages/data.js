export const UserData = [
   {
    id:1,
    Module : "Core-Java",
    percentage: 85,
    userLost:823
   } ,

   {
    id:2,
    Module:"Advance-Java",
    percentage: 70,
    userLost:995
   } ,

   {
    id:3,
    Module:"WPT",
    percentage: 65,
    userLost:543
   } ,

   {
    id:4,
    Module: "SDM",
    percentage: 77,
    userLost:534
   } ,

   {
    id:5,
    Module: "OS",
    percentage: 64,
    userLost:543
   } ,


   {
    id:6,
    Module:"DBT",
    percentage: 50,
    userLost:2000
   } ,

   {
    id:7,
    Module:"DSA",
    percentage: 70,
    userLost:123
   } 
]
package com.app.pojos;

public enum ExamType {
	THEORY, LAB, MOCK_THEORY, INTERNAL
}
